<?php
// Generated on first run. Keeps the database filename unguessable
// on hosts that ignore .htaccess. Do not edit or the app loses its data.
return 'audits-fec62a0d2508886c226e1a5a.sqlite';
